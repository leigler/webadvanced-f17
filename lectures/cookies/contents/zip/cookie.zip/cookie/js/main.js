$(document).ready(function(){

console.log("🍪   🍪   🍪   🍪   🍪   🍪   🍪  🍪   🍪   🍪   🍪\n🍪   🍪   🍪   🍪   JS Cookies   🍪   🍪   🍪   🍪\n🍪   🍪   🍪   🍪   🍪   🍪   🍪  🍪   🍪   🍪   🍪");





})