# Notes

python -m SimpleHTTPServer 8008